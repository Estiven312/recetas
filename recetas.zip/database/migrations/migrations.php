<?php

return [
    'create_categorias_table' => '2023_10_31_213808_create_categorias_table',
    'create_pais_table'=>'2023_11_01_180951_create_pais_table',
   'create_recetas_table'=>'2023_10_31_213808_create_recetas_table',
   'create_usuarios_table'=>'2023_10_27_020153_create_usuarios_table',
   'create_img_adicionals_table'=>' 2023_11_01_174216_create_img_adicionals_table'
  
];